<?php
$servername="mysql.hostinger.in";
$username="u362559069_ravi";
$password="123456";
$dbname="u362559069_reg";

$con=mysqli_connect($servername,$username,$password,$dbname);


?>