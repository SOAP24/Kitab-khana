<?php

echo "hello world";

?>