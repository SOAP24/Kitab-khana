﻿
<!DOCTYPE html>
<html>
<head>
	<title>buy novels</title>
	 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">

  
      <link rel="stylesheet" href="css/style.css">
      <style type="text/css">
	#stylebook1{
		color: black;
		text-underline-position: center;
		text-align: center;
	}
</style>
</head>
<body>
	<h1 id="stylebook1">Novels</h1>
	 <h1>Letz Shop</h1>

<div class="shopping-cart">
  
  <div class="column-labels">
    <label class="product-image">Image</label>
    <label class="product-details">Product</label>
    <label class="product-price">Price</label>
   </div>
	<div class="product">
    <div class="product-image">
      <a href="https://www.google.co.in/search?q=thinking+fast+and+slow&rlz=1C1CHBF_enIN808IN808&source=lnms&tbm=isch&sa=X&ved=0ahUKEwiYstCl-fvdAhWKtY8KHc4RCKwQ_AUIDygC&biw=1536&bih=723#imgrc=XgubfqaHhQzn_M:">
      <img src="thinking.jpg">
</a>    
<div class="identity"></div>
</div>
    <div class="product-details">
      <div class="product-title"><span id="span1">Thinking Fast and Slow(Paper back)</span></div><br><p class="product-description">
      <span id="span2">Product Description</span><br>
 'Thinking, Fast and Slowâ€™ is an International Bestseller authored by the eminent economist and psychologist Daniel Kahneman. The book takes the readers on a fascinating journey by dissecting the mind and goes onto explain two distinct systems that affects our way of thinking and making choices. Of these two systems, one is intuitive, emotional yet fast while the other one is more logical and deliberative.

      </p>
    </div>

    <div class="product-price">216</div>
  </div>


<!-- novel 2 -->
<div class="product">
    <div class="product-image">
      <a href="https://www.google.co.in/search?rlz=1C1CHBF_enIN808IN808&biw=1536&bih=674&tbm=isch&sa=1&ei=sfu9W_DNNczdvgSqqZToCQ&q=think+and+grow+rich&oq=think+and+grow+&gs_l=img.3.0.0l10.62283.71626.0.72831.18.15.1.2.2.0.269.1884.0j6j3.9.0....0...1c.1.64.img..6.12.1889.0..35i39k1j0i67k1.0.rlWu7jkdL1w#imgrc=mtCcNAc0fld-hM:">
      <img src="think.jpg">
</a>    
<div class="identity"></div>
</div>
    <div class="product-details">
      <div class="product-title"><span id="span1">Thinking Fast and Slow(Paper back)</span></div><br><p class="product-description">
      <span id="span2">Product Description</span><br>
 Think And Grow Rich has earned itself the reputation of being considered a textbook for actionable techniques that can help one get better at doing anything, not just by rich and wealthy, but also by people doing wonderful work in their respective fields. There are hundreds and thousands of successful people in the world who can vouch for the contents of this book. At the time of authorâ€™s death, about 20 million copies had already been sold. Numerous revisions have been made in the book, from time to time, to make the book more readable and comprehensible to the readers.
      </p>
    </div>

    <div class="product-price">65</div>
  </div>


  <!-- novel 3 -->
  <div class="product">
    <div class="product-image">
      <a href="https://www.google.co.in/search?rlz=1C1CHBF_enIN808IN808&biw=1536&bih=674&tbm=isch&sa=1&ei=fPu9W6nCK4zGvgTUg4PADQ&q=the+da+vinci+code+book&oq=the+da+&gs_l=img.3.2.0l10.44582.49392.0.51737.8.8.0.0.0.0.331.1016.2-3j1.4.0....0...1c.1.64.img..4.4.1015.0..35i39k1j0i67k1.0.5RLpENcxY2Y#imgrc=5gL7oyaaqMmS8M:">
      <img src="code.jpg">
</a>    
<div class="identity"></div>
</div>
    <div class="product-details">
      <div class="product-title"><span id="span1">The Da Vinci Code (Robert Langdon)</span></div><br><p class="product-description">
      <span id="span2">Product Description</span><br>
 The plot in â€˜The Da Vinci Codeâ€™ revolves around Robert Langdon, who interprets symbols at Harvard. He gets a shocking phone call at mid-night while in Paris. The administrator of the Louvre was killed in the premises of the museum and the dead body is accompanied by a sequence of codes. As Robert was supposed to meet that person, he now stands as a suspect of the murder. Robert is accompanied by Sophie Neveu, a French cryptologist, in solving the mystery revolving around the murder.

They are astonished to find that the hints they are searching for are hidden in the works of Leonardo Da Vinci. Although the clues can be seen clearly, yet they are to be decoded. As the story unfolds, it is found out that the late administrator was affiliated with some secret society and his sole purpose was to safeguard the secret. Robert and Sophie then battle to decode the secrets running from cathedrals to castles around the whole Europe.
      </p>
    </div>

    <div class="product-price">165</div>
  </div>
 


 <!-- novel 4 -->
  <div class="product">
    <div class="product-image">
      <a href="https://www.google.co.in/search?rlz=1C1CHBF_enIN808IN808&biw=1536&bih=674&tbm=isch&sa=1&ei=Nfu9W9-rFonmvgTPs7LgBw&q=how+to+win+friends+and+influence+people&oq=how+to+win+frien&gs_l=img.3.0.0l10.42816.67958.0.69813.47.37.4.4.5.0.515.4212.0j4j8j2j1j1.16.0....0...1c.1.64.img..25.22.3843.0..0i67k1j35i39k1j0i10k1.0.DLS502eExFw#imgrc=AIO5yQUflqgr_M:">
      <img src="friends.jpg">
</a>    
<div class="identity"></div>
</div>
    <div class="product-details">
      <div class="product-title"><span id="span1">How to win Friends and Influence people</span></div><br><p class="product-description">
      <span id="span2">Product Description</span><br>
'How to win friends and influence peopleâ€™ is a self-help book which is the pioneer of this genre. Written by Dale Carnegie and published in 1936, it has sold over 30 million copies. It has been edited and re-printed several times. This is the 2004 edition of this book. It was on the Time magazineâ€™s 100 most influential books list in 2011. This book is a guide in improving a person's aura in the world. It is about changing how the world views and treats you by changing your own behaviour. That means that if you change the kind of energy that you emit, what comes back to you is also different. This is one of the most influential business and communication skills guide. This book teaches you how to market yourself and generate more clients. This book has been acclaimed by many known figures around the world. This book tries to get you out of a mental hell and provides you with ambition and goals.

      </p>
    </div>

    <div class="product-price">108</div>
  </div>


 <!--  novel 5 -->
<div class="product">
    <div class="product-image">
      <a href="https://www.google.co.in/search?rlz=1C1CHBF_enIN808IN808&biw=1536&bih=674&tbm=isch&sa=1&ei=-Pq9W7XyGYn4vgT8k5qACA&q=the+power+of+the+subconscious+mind+joseph+murphy&oq=the+power+of+the+subc&gs_l=img.3.0.0l7j0i30k1j0i24k1l2.52800.57922.0.59676.22.17.0.3.3.0.354.2122.0j3j5j1.9.0....0...1c.1.64.img..10.12.2131.0..35i39k1j0i67k1.0.j_kiIFVoccA#imgrc=slzm7hkLO713BM:">
      <img src="power.jpg">
</a>    
<div class="identity"></div>
</div>
    <div class="product-details">
      <div class="product-title"><span id="span1">The Power of your Subconscious Mind</span></div><br><p class="product-description">
      <span id="span2">Product Description</span><br>
 
This book can bring to your notice the innate power that the sub-conscious holds. We have some traits which seem like habits, but in reality these are those traits which are directly controlled by the sub-conscious mind, vis-Ã -vis your habits or your routine can be changed if you can control and direct your sub-conscious mind positively. To be able to control this 'mind power' and use it to improve the quality of your life is no walk in the park. This is where this book acts as a guide and allows you to decipher the depths of the sub-conscious.
      </p>
    </div>

    <div class="product-price">220</div>
   </div>
  

<!-- novel 6 -->
  <div class="product">
    <div class="product-image">
      <a href="https://www.google.co.in/search?rlz=1C1CHBF_enIN808IN808&biw=1536&bih=674&tbm=isch&sa=1&ei=Vvq9W--cDcn0vATxv4zQDg&q=the+one+thing&oq=the+one+thing&gs_l=img.3..0l10.158055.159787.0.160051.14.8.0.0.0.0.394.940.2-1j2.3.0....0...1c.1.64.img..11.3.940.0..0i67k1.0.vH2EoAjBJFE#imgrc=4jkgt6Y3IlFH6M:">
      <img src="one thing.jpg">
</a>    
<div class="identity"></div>
</div>
    <div class="product-details">
      <div class="product-title"><span id="span1">The One Thing </span></div><br><p class="product-description">
      <span id="span2">Product Description</span><br>
 The ONE Thing: The Surprisingly Simple Truth Behind Extraordinary Results is a 2013 book written by authors Gary Keller and Jay Papasan. The book, The One Thing, explains how the habit to succeed can be incorporated in our life to overcome the hurdles like the lies that will block our success, the thieves that will steal our time and increase our concentration in the purpose, the way we prioritize and the productivity of our business. The book comes in handy for people indulged in business and helps them increase the efficiency of their work and remove the hindering factors. The book is easy to read and substantial in the ideas it conveys.

      </p>
    </div>
    <div class="product-price">258</div>
  </div>



</body>
</html>