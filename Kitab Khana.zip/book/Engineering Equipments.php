
<!DOCTYPE html>
<html>
<head>
	<title></title>
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">

  
      <link rel="stylesheet" href="css/style.css">

<style type="text/css">
	#stylebook1{
		color: black;
		text-underline-position: center;
		text-align: center;
	}
</style>

</head>
<body>
	<h1 id="stylebook1">Engineering Equipments</h1>
	 <h1>Letz Shop</h1>

<div class="shopping-cart">
  
  <div class="column-labels">
    <label class="product-image">Image</label>
    <label class="product-details">Product</label>
    <label class="product-price">Price</label>
  </div>

	<div class="product">
    <div class="product-image">
      <a href="https://www.google.co.in/search?q=Seagate+1TB+Backup+Plus+Slim+USB+3.0+External+Hard+Drive+2.5+Inch+for+PC+and+Mac+with+2+Months+Free+Adobe+Creative+Cloud+Photography+Plan+-+Black&rlz=1C1CHBF_enIN808IN808&source=lnms&tbm=isch&sa=X&ved=0ahUKEwiy-fHXjvndAhUPO3AKHXE2BdQQ_AUIDygC&biw=1536&bih=674#imgrc=MkMHEHTPel86wM:">
      <img src="hard disk seagate.jpg">
</a>    
<div class="identity">Id=7</div>
</div>
    <div class="product-details">
      <div class="product-title"><span id="span1">Seagate 1TB Backup Plus Slim USB 3.0 External Hard Drive 2.5 Inch for PC and Mac with 2 Months Free Adobe Creative Cloud Photography Plan - Black</span></div><br><p class="product-description">
      <span id="span2">Product Description</span><br>
     Technical Details<br>
Brand Seagate
Series  Backup Plus Slim
Colour  Black<br>

Product Dimensions  7.6 x 2.1 x 11.4 cm<br>
Batteries:  1 Lithium ion batteries required.
Item model number STDR1000300<br>
Hard Drive Size 1 TB<br>
Hard Drive Interface  USB 1.1<br>

Included Components Backup Plus Slim Portable Drive, 18 inch USB 3.0 Cable, Quick Start Guide, Seagate Dashboard Backup Software,NTFS Driver for Mac
      <p><span id="span2">Product details:</span>
      <br>
Item Height 11.4 Centimeters<br>
Item Width  21 Millimeters<br>
Item Weight 159 g<br>


      </p>
    </div>

    <div class="product-price">3500</div>
  </div>
<!-- equipment 2 -->
<div class="product">
    <div class="product-image">
      <a href="https://www.google.co.in/search?rlz=1C1CHBF_enIN808IN808&biw=1536&bih=674&tbm=isch&sa=1&ei=Gn68W7K1CYzr-QbwnqGQDQ&q=Seagate+Expansion+1.5TB+USB+3.0+Portable+2.5+Inch+External+Hard+Drive+for+PC%2C+Xbox+One+and+Playstation+4&oq=Seagate+Expansion+1.5TB+USB+3.0+Portable+2.5+Inch+External+Hard+Drive+for+PC%2C+Xbox+One+and+Playstation+4&gs_l=img.3...102747.108185.0.108702.40.10.0.0.0.0.625.625.5-1.1.0....0...1c.1.64.img..39.0.0.0...0.WThZMe3arR0#imgrc=hm9t58DZkeO7sM:">
      <img src="seagate 1 tb.jpg">
</a>    
<div class="identity">Id=9</div>
</div>
    <div class="product-details">
      <div class="product-title"><span id="span1">Seagate Expansion 1.5TB USB 3.0 Portable 2.5 Inch External Hard Drive for PC, Xbox One and Playstation 4</span></div><br><p class="product-description">
      <span id="span2">Product Description</span><br>
     Technical Details<br>

Brand Seagate<br>
Series  Expansion<br>
Product Dimensions  8 x 1.5 x 11.7 cm<br>
Item model number STEA1500400<br>
Hard Drive Size 1.5 TB<br>
Hard Drive Interface  USB 3.0<br>
Wireless Type Radio Frequency<br>
Power Source  No<br>


  <p><span id="span2">Product details:</span>
      <br>
Item Height 11.7 Centimeters<br>
Item Width  15 Millimeters<br>
Item Weight 168 g<br>


      </p>
    </div>

    <div class="product-price">3800</div>
   </div>

<!-- equiment 3 -->
<div class="product">
    <div class="product-image">
      <a href="https://www.google.co.in/search?rlz=1C1CHBF_enIN808IN808&biw=1536&bih=674&tbm=isch&sa=1&ei=iH68W4TxMNOEoAS9mpqACg&q=Nandini+Engineering+Combo+Set+of+4+Products+Mini+Drafter%2C+Scale%2C+Set+Squares%2C+Pro+Circle+180%2C+Sheet+Containe&oq=Nandini+Engineering+Combo+Set+of+4+Products+Mini+Drafter%2C+Scale%2C+Set+Squares%2C+Pro+Circle+180%2C+Sheet+Containe&gs_l=img.3...471454.472318.0.473052.2.2.0.0.0.0.0.0..0.0....0...1c.1.64.img..2.0.0.0...0.gza4QlzoNXM#imgrc=7UGgdeAvRTLpKM:">
      <img src="drafter.jpg">
</a>    
<div class="identity">Id=9</div>
</div>
    <div class="product-details">
      <div class="product-title"><span id="span1">Nandini Engineering Combo Set of 4 Products Mini Drafter, Scale, Set Squares, Pro Circle 180, Sheet Containe</span></div><br><p class="product-description">
      <span id="span2">Product Description</span><br>
    Technical Details<br>
Brand NANDINI ENTERPRISES<br>
Model Number  NET 201<br>
Colour  Multi-Colour<br>
Manufacturer Part Number  NET 10238<br>


  <p><span id="span2">Product details:</span>
      <br>
Ideal For Engineering Students & professional .
packing is done with care so that it reach to you safely<br>
A nice collectable,and a good gift for Engineers .<br>
A quality product from House of Nandini<br>


      </p>
    </div>

    <div class="product-price">540</div>
  </div>

<!-- equipment 4 -->
<div class="product">
    <div class="product-image">
      <a href="https://www.google.co.in/search?rlz=1C1CHBF_enIN808IN808&biw=1536&bih=723&tbm=isch&sa=1&ei=-Km9W6mHD4XdrQHfxZnIAQ&q=sandisk+pendrive+32gb&oq=scandisk+pen&gs_l=img.3.3.0i10i24k1l10.2986.4447.0.7204.4.4.0.0.0.0.605.1256.0j2j1j5-1.4.0....0...1c.1.64.img..0.4.1255...0j0i10i67k1j0i10k1j0i8i30k1.0.Dcd5Qcuw7Vs#imgrc=XjgCFi3XfpAOaM:">
      <img src="download.jpg">
</a>    
<div class="identity">Id=10</div>
</div>
    <div class="product-details">
      <div class="product-title"><span id="span1">SanDisk Cruzer Blade 32GB USB Flash Drive</span></div><br><p class="product-description">
      <span id="span2">Product Description</span><br>
    Technical Details<br>
Brand SanDisk<br>
Colour  RED & BLACK<br>
Item Height 41 Millimeters<br>
Item Width  18 Millimeters<br>
Item Weight 9.07 g<br>
Product Dimensions  73.7 x 1.8 x 4.1 cm<br>
Item model number SDCZ50-032G-B35<br>
Processor Count 1<br>
RAM Size  32 GB<br>
Computer Memory Type  DDR3 SDRAM<br>
Number of USB 2.0 Ports 1<br>
Included Components Pen Drives or USB Flash Drives<br>
  <p><span id="span2">Product details:</span>
      <br>
Ultra-compact and portable USB flash drive<br>
Share your photos, videos, songs and other files between computers with ease<br>
Protect your private files with included SanDisk SecureAccess software<br>
Includes added protection of secure online backup (up to 2GB optionally available) offered by YuuWaa<br>
Password-protect your sensitive files<br>
Capless design<br>
Share your work files between computers with ease<br>


      </p>
    </div>

    <div class="product-price">420</div>
  </div>
<!-- equiment 5 -->
<div class="product">
    <div class="product-image">
      <a href="https://www.google.co.in/search?rlz=1C1CHBF_enIN808IN808&biw=1536&bih=674&tbm=isch&sa=1&ei=JYa8W4qZO5PW-QaWzIHIBw&q=Casio+FX-82MS+2-Line+Display+Scientific+Calculator&oq=Casio+FX-82MS+2-Line+Display+Scientific+Calculator&gs_l=img.3..0i24k1.439009.440231.0.440824.2.2.0.0.0.0.304.304.3-1.1.0....0...1c.1.64.img..1.1.302.0...0.MfTjwesph64#imgrc=fIuE4OwNIIw16M:">
      <img src="casio.jpg">
</a>    
<div class="identity">Id=11</div>
</div>
    <div class="product-details">
      <div class="product-title"><span id="span1">Casio FX-82MS 2-Line Display Scientific Calculator
by Casio</span></div><br><p class="product-description">
      <span id="span2">Product Description</span><br>
    Black coloured calculator , designed and engineered for easy operation .<br>
Large keypad for comfortable use of the user.
Battery powered .<br>
It has a large display so that it is easy to read and use.<br>
Color coded keypad for easy key differentiation.<br>
It has a complete calculation feature with a full decimal system.<br>
Displays numbers in three digit separator formats (Standard, European, and Indian)<br>
It saves upto 150 previous calculations<br>
All the mark-up capabilities of an adding machine for simplified cost and profit calculations<br>
Lightweight and easy to port.<br>

      </p>
    </div>

    <div class="product-price">404</div>
  </div>


<!-- equiment 6 -->
<div class="product">
    <div class="product-image">
      <a href="https://www.google.co.in/search?rlz=1C1CHBF_enIN808IN808&biw=1536&bih=674&tbm=isch&sa=1&ei=4Ie8W5j6MpG5wAPXjYCwCQ&q=Hug+Me+Drwaing+Sheet+or+Art+Paper+or+Jumbo+paper+Containe&oq=Hug+Me+Drwaing+Sheet+or+Art+Paper+or+Jumbo+paper+Containe&gs_l=img.3...275801.276557.0.276841.2.2.0.0.0.0.250.250.2-1.1.0....0...1c.1.64.img..1.0.0.0...0.SNSk96KLq1g#imgrc=GniJpNwREzJd_M:">
      <img src="hugme.jpg">
</a>    
<div class="identity">Id=12</div>
</div>
    <div class="product-details">
      <div class="product-title"><span id="span1">Hug Me Drwaing Sheet or Art Paper or Jumbo paper Container</span></div><br><p class="product-description">
      <span id="span2">Product Description</span><br>
  Type- Drawing Tube Holder Or Sheet <br>Container,Expands from more than 1 foot or 12" to 2 feet or 24" long ( 30+ cm to 60+ cm) ,Interior diameter approx 2.5 inches.<br>
Carry your artworks, plans, posters and prints in Artists' Storage Tubes.This roll pack helps to carry with importance Sheet, Paper, Art paper, Any kind of valuable paper ,<br>
Moreover this water resistance so papers are saved from water. It will protect your work while you are on the move or go.<br>
Ideal to use to store your work when you have little space.<br>
Includes removable and adjustable shoulder strap.<br>

      </p>
    </div>

    <div class="product-price">170</div>
   </div>

 

</body>
</html>